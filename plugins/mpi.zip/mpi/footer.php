		<?php echo $mpi->git_branch(); ?>
		
		</div> <!-- /div.container -->
	</body>
</html>
